# My Flipper Shits
    
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Faleff-github%2Fmy-flipper-shits&count_bg=%233C3C3C&title_bg=%233C3C3C&icon=linux.svg&icon_color=%23FFFFFF&title=views&edge_flat=false)](https://github.com/aleff-github/my-flipper-shits) [![GitHub Sponsor](https://img.shields.io/github/sponsors/aleff-github?label=Sponsor&logo=GitHub&style=for-the-badge)](https://github.com/sponsors/aleff-github) [![Licence](https://img.shields.io/badge/Licence-GPLv3-%239e264c?style=for-the-badge)](https://github.com/aleff-github/my-flipper-shits/blob/main/LICENCE)

* [Disclaimer](#disclaimer)
* [PlugAndPlay (PAP) Legend](#plugandplay-pap-legend)
* [Payloads](#payloads)
* [Videos](#videos)
* [FAQs](#faqs)
* [Credits](#credits)
* [Donations](#donations)


## Disclaimer

<div align=center>

<img src="https://raw.githubusercontent.com/aleff-github/my-flipper-shits/main/img/logo-repository-2_0.gif" width="600" /><br><img src="https://raw.githubusercontent.com/aleff-github/my-flipper-shits/main/img/DISCLAIMER.png" width="600" />

</div>


## PlugAndPlay (PAP) Legend

- 🟢 Totally - You must do nothing
- 🟡 Partial - Just something like a Dropbox Token or Discord Webhook...
- 🔴 Manual effort request


## Payloads

|System|Category|Name|PAP|
|--|--|--|--|
|![iOS](https://img.shields.io/badge/iOS-000000?style=for-the-badge&logo=ios&logoColor=white)|Prank|[Play A Song With An iPhone](https://github.com/aleff-github/my-flipper-shits/tree/main/iOS/Prank/Play_A_Song_With_An_iPhone)|🟡|
|![iOS](https://img.shields.io/badge/iOS-000000?style=for-the-badge&logo=ios&logoColor=white)|Prank|[Call Someone With An iPhone](https://github.com/aleff-github/my-flipper-shits/tree/main/iOS/Prank/Call_Someone_With_An_iPhone)|🟡|
|![iOS](https://img.shields.io/badge/iOS-000000?style=for-the-badge&logo=ios&logoColor=white)|Prank|[Edit A Reminder With An iPhone](https://github.com/aleff-github/my-flipper-shits/tree/main/iOS/Prank/Edit_A_Reminder_With_An_iPhone)|🟡|
|![iOS](https://img.shields.io/badge/iOS-000000?style=for-the-badge&logo=ios&logoColor=white)|Prank|[Delete A Reminder With An iPhone](https://github.com/aleff-github/my-flipper-shits/tree/main/iOS/Prank/Delete_A_Reminder_With_An_iPhone)|🟡|


## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://raw.githubusercontent.com/aleff-github/aleff-github/main/img/github.png width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://raw.githubusercontent.com/aleff-github/aleff-github/main/img/linkedin.png width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>

## Donations

- [![](https://img.shields.io/static/v1?label=Sponsor&message=%E2%9D%A4&logo=GitHub&color=%23fe8e86)](https://github.com/sponsors/aleff-github)
- [GitHub Sponsor](https://github.com/sponsors/aleff-github)
- [PayPal](paypal.me/aleg599)
- BTC: 38cCkZtCxGBqny4xvDKbtUbe1d88psVNU5
