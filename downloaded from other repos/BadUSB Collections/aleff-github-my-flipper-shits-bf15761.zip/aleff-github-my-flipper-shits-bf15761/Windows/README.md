# My Flipper Shits
    
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Faleff-github%2Fmy-flipper-shits&count_bg=%233C3C3C&title_bg=%233C3C3C&icon=linux.svg&icon_color=%23FFFFFF&title=views&edge_flat=false)](https://github.com/aleff-github/my-flipper-shits) [![GitHub Sponsor](https://img.shields.io/github/sponsors/aleff-github?label=Sponsor&logo=GitHub&style=for-the-badge)](https://github.com/sponsors/aleff-github) [![Licence](https://img.shields.io/badge/Licence-GPLv3-%239e264c?style=for-the-badge)](https://github.com/aleff-github/my-flipper-shits/blob/main/LICENCE)

* [Disclaimer](#disclaimer)
* [PlugAndPlay (PAP) Legend](#plugandplay-pap-legend)
* [Payloads](#payloads)
* [Videos](#videos)
* [FAQs](#faqs)
* [Credits](#credits)
* [Donations](#donations)


## Disclaimer

<div align=center>

<img src="https://raw.githubusercontent.com/aleff-github/my-flipper-shits/main/img/logo-repository-2_0.gif" width="600" /><br><img src="https://raw.githubusercontent.com/aleff-github/my-flipper-shits/main/img/DISCLAIMER.png" width="600" />

</div>


## PlugAndPlay (PAP) Legend

- 🟢 Totally - You must do nothing
- 🟡 Partial - Just something like a Dropbox Token or Discord Webhook...
- 🔴 Manual effort request


## Payloads

|System|Category|Name|PAP|
|--|--|--|--|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Credentials|[WiFi Windows Passwords](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Credentials/WiFiPasswords_Windows)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Credentials|[Defend Yourself From CVE-2023-23397](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Credentials/Defend_yourself_from_CVE-2023-23397)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Exfiltrate Process Info - Windows](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/ExfiltrateProcessInfo_Windows)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[ProtonVPN config](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/ProtonVPNConfigFile_Windows)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Windows netstat](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Netstat_Windows)|🔴|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Exfiltrate Computer Screenshots](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/ExfiltrateComputerScreenshots)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Export Cookies From Firefox](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Export_Cookies_From_Firefox)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Exports all the links of the downloads](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Exports_all_the_links_of_the_downloads)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Tree structure of the operating system](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Tree_structure_of_the_operating_system)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Export all saved certificates with Adobe Reader](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Export_all_saved_certificates_with_Adobe_Reader)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Exfiltrates the entire database of the Notion client](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Exfiltrates_the_entire_database_of_the_Notion_client)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Create And Exfiltrate A Webhook Of Discord](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Create_And_Exfiltrate_A_Webhook_Of_Discord)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Close All Applications](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/CloseAllApplications_Windows)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Uninstall Signal](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/UninstallSignal)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Set An Arbitrary DNS - IPv4 version](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Set_An_Arbitrary_DNS-IPv4_version)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Add An Excepiton To Avast Antivirus](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Add_An_Excepiton_To_Avast_Antivirus)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Make Windows performant (but ugly and boring)](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Make_Windows_performant_(but_ugly_and_boring))|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Change Windows User Name](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Change_Windows_User_Name)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Starting a PowerShell with administrator permissions in Windows](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Starting_a_PowerShell_with_administrator_permissions_in_Windows)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Change the password of the Windows user](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Change_the_password_of_the_windows_user)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Stop A Single Process In Windows](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Stop_A_Single_Process_In_Windows)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Uninstall A Specific App On Windows Through Control Panel](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Uninstall_A_Specific_App_On_Windows_Through_Control_Panel)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Change Git Remote Link](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/ChangeGitRemoteLink)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Send Messages In Discord Channel-Server](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Send_Messages_In_Discord_Channel-Server)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Install And Run Any Arbitrary Executable - No Internet And Root Needed](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Install_And_Run_Any_Arbitrary_Executable-No_Internet_And_Root_Needed)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Send Signal Messages](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/SendSignalMessages_Windows)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Send Microsoft Teams Messages](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/SendMessagesInTeams)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Never Gonna Give You Up](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/NeverGonnaGiveYouUp_Windows)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Alien Message From Computer](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/AlienMessageFromComputer)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Continuous Print In Terminal](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/ContinuousPrintInTerminal)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Change Wallpaper With Screenshot](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/ChangeWallpaperWithScreenshot)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Play A Song Through Spotify](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/PlayASongThroughSpotify)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Full-Screen Banner Joke](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/Full-ScreenBannerJoke)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[The Mouse Moves By Itself](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/The_Mouse_Moves_By_Itself)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Try To Catch Me](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/Try_To_Catch_Me)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Follow Someone On Instagram](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/Follow_Someone_On_Instagram)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Pranh(ex)](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/Pranh(ex))|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Send Email Through Thunderbird](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/SendEmailThroughThunderbird)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Change Github Profile Settings](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/Change_Github_Profile_Settings)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Incident Response|[Defend yourself against CVE-2023-36884 Office and Windows HTML Remote Code Execution Vulnerability](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/incident_response/Defend_yourself_against_CVE-2023-36884_Office_and_Windows_HTML_Remote_Code_Execution_Vulnerability)|🟢|
|//|Prank|[Flipper Zero GIF](img/gif)|🟢|


## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://raw.githubusercontent.com/aleff-github/aleff-github/main/img/github.png width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://raw.githubusercontent.com/aleff-github/aleff-github/main/img/linkedin.png width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>

## Donations

- [![](https://img.shields.io/static/v1?label=Sponsor&message=%E2%9D%A4&logo=GitHub&color=%23fe8e86)](https://github.com/sponsors/aleff-github)
- [GitHub Sponsor](https://github.com/sponsors/aleff-github)
- [PayPal](paypal.me/aleg599)
- BTC: 38cCkZtCxGBqny4xvDKbtUbe1d88psVNU5
