# Follow someone on Instagram

This script can be used play a prank on friends by having them follow an Instagram account.

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Faleff-github%2Fmy-flipper-shits&count_bg=%233C3C3C&title_bg=%233C3C3C&icon=linux.svg&icon_color=%23FFFFFF&title=views&edge_flat=false)](https://github.com/aleff-github/my-flipper-shits)

**Category**: Prank

<div align=center>

<img src="https://github.com/aleff-github/my-flipper-shits/blob/main/img/logo-repository-2_0.gif" width="600" /><br><img src="https://github.com/aleff-github/my-flipper-shits/blob/main/img/DISCLAIMER.png" width="600" />

</div>

## Description

This script can be used play a prank on friends by having them follow an Instagram account.

Open a PowerShell, start a process trough the default browser that go to an instagram link like this one `https://www.instagram.com/alessandro_greco_aka_aleff/` closing the PowerShell. Then use some TABs to go to Follow button and then close the browser.

## Note

Tested on:
- Windows 11 Eng
- Firefox Browser Eng

## Dependencies

* Internet Connection
* Instagram account logged in

## Settings

- You must set the Instagram account that you want to follow i.e. https://www.instagram.com/alessandro_greco_aka_aleff/

    `[17] DEFINE #INSTAGRAM_LINK example`

- It depends by the computer power and by the internet connection power

    `[32] DELAY 2000`

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>