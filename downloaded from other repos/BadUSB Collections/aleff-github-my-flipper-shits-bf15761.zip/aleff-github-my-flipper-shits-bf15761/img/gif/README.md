
<div align=center>

<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/flipper_zero.jpg width="200" />
 <br>
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(1).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(2).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(3).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(4).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(5).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(6).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(7).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(8).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(9).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(10).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(11).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(12).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(13).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(14).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(15).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(16).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(17).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(18).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(19).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(20).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(21).gif width="100" />
<img src= https://github.com/aleff-github/my-flipper-shits/blob/main/img/gif/flipper_zero%20(22).gif width="100" />

</div>
