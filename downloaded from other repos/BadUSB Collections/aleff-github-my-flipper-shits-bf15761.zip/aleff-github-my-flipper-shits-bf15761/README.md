# My Flipper Shits
    
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Faleff-github%2Fmy-flipper-shits&count_bg=%233C3C3C&title_bg=%233C3C3C&icon=linux.svg&icon_color=%23FFFFFF&title=views&edge_flat=false)](https://github.com/aleff-github/my-flipper-shits) [![GitHub Sponsor](https://img.shields.io/github/sponsors/aleff-github?label=Sponsor&logo=GitHub&style=for-the-badge)](https://github.com/sponsors/aleff-github) [![Licence](https://img.shields.io/badge/Licence-GPLv3-%239e264c?style=for-the-badge)](https://github.com/aleff-github/my-flipper-shits/blob/main/LICENCE)

* [Disclaimer](#disclaimer)
* [PlugAndPlay (PAP) Legend](#plugandplay-pap-legend)
* [Stats](#stats)
* [Payloads](#payloads)
* [Videos](#videos)
* [FAQs](#faqs)
* [Credits](#credits)
* [Donations](#donations)


## Disclaimer

<div align=center>

<img src="https://raw.githubusercontent.com/aleff-github/my-flipper-shits/main/img/logo-repository-2_0.gif" width="600" /><br><img src="https://raw.githubusercontent.com/aleff-github/my-flipper-shits/main/img/DISCLAIMER.png" width="600" />

</div>


## PlugAndPlay (PAP) Legend

- 🟢 Totally - You must do nothing
- 🟡 Partial - Just something like a Dropbox Token or Discord Webhook...
- 🔴 Manual effort request


## Stats

|Type|Count|
|--|--|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|26|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|40|
|![iOS](https://img.shields.io/badge/iOS-000000?style=for-the-badge&logo=ios&logoColor=white)|4|
|![macOS](https://img.shields.io/badge/mac%20os-000000?style=for-the-badge&logo=macos&logoColor=F0F0F0)|0 [Buy me a Mac](https://github.com/sponsors/aleff-github?frequency=one-time&sponsor=aleff-github) :-)|
|**Tot**|70|
|Hak5|41|


## Payloads

|System|Category|Name|PAP|
|--|--|--|--|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Credentials|[WiFi Windows Passwords](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Credentials/WiFiPasswords_Windows)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Credentials|[Defend Yourself From CVE-2023-23397](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Credentials/Defend_yourself_from_CVE-2023-23397)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Exfiltrate Process Info - Windows](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/ExfiltrateProcessInfo_Windows)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[ProtonVPN config](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/ProtonVPNConfigFile_Windows)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Windows netstat](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Netstat_Windows)|🔴|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Exfiltrate Computer Screenshots](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/ExfiltrateComputerScreenshots)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Export Cookies From Firefox](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Export_Cookies_From_Firefox)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Exports all the links of the downloads](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Exports_all_the_links_of_the_downloads)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Tree structure of the operating system](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Tree_structure_of_the_operating_system)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Export all saved certificates with Adobe Reader](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Export_all_saved_certificates_with_Adobe_Reader)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Exfiltrates the entire database of the Notion client](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Exfiltrates_the_entire_database_of_the_Notion_client)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Exfiltration|[Create And Exfiltrate A Webhook Of Discord](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Exfiltration/Create_And_Exfiltrate_A_Webhook_Of_Discord)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Exfiltration|[Exfiltrate Process Info - Linux](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Exfiltration/ExfiltrateProcessInfo_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Exfiltration|[Exfiltrate Network Traffic](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Exfiltration/ExfiltrateNetworkTraffic_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Exfiltration|[Exfiltrate Linux Documents](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Exfiltration/ExfiltrateDocumentsFolder_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Exfiltration|[Exfiltrate Linux Logs](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Exfiltration/ExfiltrateLogFiles_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Exfiltration|[Exfiltrate Network Configuration](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Exfiltration/ExfiltrateNetworkConfiguration_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Exfiltration|[Exfiltrate Email And Password By Phising](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Exfiltration/ExfiltrateEmailAndPasswordByPhising_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Exfiltration|[Exfiltrate Sudo Password By Phishing](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Exfiltration/ExfiltrateSudoPasswordByPhising_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Exfiltration|[Exfiltrate WiFi Passwords](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Exfiltration/ExfiltrateWiFiPasswords_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Exfiltration|[Exfiltrate Photos Through Shell](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Exfiltration/ExfiltratePhotosThroughShell)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Phising|[Standard Phishing Attack](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Phising/StandardPhishingAttack_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Phising|[Standard Phishing Payload Using kdialog](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Phising/StandardPhishingPayloadUsingKdialog_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Execution|[Exploiting An Executable File](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Execution/ExploitingAnExecutableFile)|🟢|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Execution|[Change MAC Address](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Execution/ChangeMacAddress_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Execution|[Set Arbitrary VPN](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Execution/SetArbitraryVPN_Linux)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Close All Applications](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/CloseAllApplications_Windows)|🟢|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Execution|[Change Network Configuration](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Execution/ChangeNetworkConfiguration_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Execution|[Edit The Default Real App With An Arbitrary](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Execution/Edit_The_Default_Real_App_With_An_Arbitrary)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Uninstall Signal](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/UninstallSignal)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Set An Arbitrary DNS - IPv4 version](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Set_An_Arbitrary_DNS-IPv4_version)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Add An Excepiton To Avast Antivirus](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Add_An_Excepiton_To_Avast_Antivirus)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Make Windows performant (but ugly and boring)](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Make_Windows_performant_(but_ugly_and_boring))|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Change Windows User Name](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Change_Windows_User_Name)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Starting a PowerShell with administrator permissions in Windows](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Starting_a_PowerShell_with_administrator_permissions_in_Windows)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Change the password of the Windows user](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Change_the_password_of_the_windows_user)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Stop A Single Process In Windows](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Stop_A_Single_Process_In_Windows)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Uninstall A Specific App On Windows Through Control Panel](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Uninstall_A_Specific_App_On_Windows_Through_Control_Panel)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Execution|[Persistent Reverse Shell - Telegram Based](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Execution/Persistent_Reverse_Shell-Telegram_Based)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Execution|[Telegram Persistent Connection Linux](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Execution/Telegram_Persistent_Connection_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Execution|[Persistent Keylogger - Telegram Based](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Execution/Persistent_Keylogger-Telegram_Based)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Execution|[Change Git Remote Link](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Execution/ChangeGitRemoteLink)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Change Git Remote Link](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/ChangeGitRemoteLink)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Send Messages In Discord Channel-Server](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Send_Messages_In_Discord_Channel-Server)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Execution|[Install And Run Any Arbitrary Executable - No Internet And Root Needed](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Execution/Install_And_Run_Any_Arbitrary_Executable-No_Internet_And_Root_Needed)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Execution|[Defend yourself against AtlasVPN bugdoor](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Execution/Defend_yourself_against_AtlasVPN_bugdoor)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)**KDE**|Prank|[Change Desktop Wallpaper](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Prank/ChangeDesktopWallpaper_LinuxKDE)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Send Signal Messages](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/SendSignalMessages_Windows)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Send Microsoft Teams Messages](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/SendMessagesInTeams)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Never Gonna Give You Up](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/NeverGonnaGiveYouUp_Windows)|🟢|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Prank|[Send Telegram Messages](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Prank/SendTelegramMessages_Linux)|🟡|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Prank|[Change The App That Will Be Runned](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/Prank/Change_The_App_That_Will_Be_Runned)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Alien Message From Computer](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/AlienMessageFromComputer)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Continuous Print In Terminal](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/ContinuousPrintInTerminal)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Change Wallpaper With Screenshot](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/ChangeWallpaperWithScreenshot)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Play A Song Through Spotify](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/PlayASongThroughSpotify)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Full-Screen Banner Joke](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/Full-ScreenBannerJoke)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[The Mouse Moves By Itself](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/The_Mouse_Moves_By_Itself)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Try To Catch Me](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/Try_To_Catch_Me)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Follow Someone On Instagram](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/Follow_Someone_On_Instagram)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Pranh(ex)](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/Pranh(ex))|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Send Email Through Thunderbird](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/SendEmailThroughThunderbird)|🟢|
|![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)|Prank|[Send Email Through Thunderbird](https://github.com/aleff-github/my-flipper-shits/tree/main/GNU-Linux/SendEmailThroughThunderbird)|🟢|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Prank|[Change Github Profile Settings](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/Prank/Change_Github_Profile_Settings)|🟡|
|![iOS](https://img.shields.io/badge/iOS-000000?style=for-the-badge&logo=ios&logoColor=white)|Prank|[Play A Song With An iPhone](https://github.com/aleff-github/my-flipper-shits/tree/main/iOS/Prank/Play_A_Song_With_An_iPhone)|🟡|
|![iOS](https://img.shields.io/badge/iOS-000000?style=for-the-badge&logo=ios&logoColor=white)|Prank|[Call Someone With An iPhone](https://github.com/aleff-github/my-flipper-shits/tree/main/iOS/Prank/Call_Someone_With_An_iPhone)|🟡|
|![iOS](https://img.shields.io/badge/iOS-000000?style=for-the-badge&logo=ios&logoColor=white)|Prank|[Edit A Reminder With An iPhone](https://github.com/aleff-github/my-flipper-shits/tree/main/iOS/Prank/Edit_A_Reminder_With_An_iPhone)|🟡|
|![iOS](https://img.shields.io/badge/iOS-000000?style=for-the-badge&logo=ios&logoColor=white)|Prank|[Delete A Reminder With An iPhone](https://github.com/aleff-github/my-flipper-shits/tree/main/iOS/Prank/Delete_A_Reminder_With_An_iPhone)|🟡|
|![Windows](https://img.shields.io/badge/Windows-0078D6?style=for-the-badge&logo=windows&logoColor=white)|Incident Response|[Defend yourself against CVE-2023-36884 Office and Windows HTML Remote Code Execution Vulnerability](https://github.com/aleff-github/my-flipper-shits/tree/main/Windows/incident_response/Defend_yourself_against_CVE-2023-36884_Office_and_Windows_HTML_Remote_Code_Execution_Vulnerability)|🟢|
|//|Prank|[Flipper Zero GIF](img/gif)|🟢|


## Videos

|Name|Link|
|--|--|
|[Close All Applications](https://github.com/aleff-github/my-flipper-shits/tree/main/CloseAllApplications_Windows)|https://youtube.com/shorts/fbXgI-4ABhU|
|[Never Gonna Give You Up](https://github.com/aleff-github/my-flipper-shits/tree/main/NeverGonnaGiveYouUp_Windows)|https://youtube.com/shorts/XRY_MEYQUxA|


## FAQs

<details>
<ul>
    <li><strong>DEFINE</strong> doesn't work!
        <ul>
            <li>DEFINEs in FlipperZero probably don't work, if they give you an error just remove them by directly entering what you want in the appropriate place</li>
        </ul>
    </li>
    <li><strong>REM</strong> errors
        <ul>
            <li>If you have an error on a REM line make sure it is not a blank line. In any case, REMs are comments and can be deleted so try deleting the line that gives you an error to see if it fixes the problem.</li>
        </ul>
    </li>
    <li><strong>bit.ly</strong> link broken - 404 problems
        <ul>
            <li><a href="https://github.com/aleff-github/my-flipper-shits/issues/3">Solution</a> In the Rick Roll video prank it's calling for a bit.ly and seems to go to a github 404 page</li>
        </ul>
    </li>
</ul>
</details>

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://raw.githubusercontent.com/aleff-github/aleff-github/main/img/github.png width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://raw.githubusercontent.com/aleff-github/aleff-github/main/img/linkedin.png width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>

## Donations

- [![](https://img.shields.io/static/v1?label=Sponsor&message=%E2%9D%A4&logo=GitHub&color=%23fe8e86)](https://github.com/sponsors/aleff-github)
- [GitHub Sponsor](https://github.com/sponsors/aleff-github)
- BTC: 38cCkZtCxGBqny4xvDKbtUbe1d88psVNU5
