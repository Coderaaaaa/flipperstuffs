# Set Arbitrary VPN - Linux ✅

A script used to set an arbitrary VPN on a Linux machine.

**Category**: Execution

## Description

A script used to set an arbitrary VPN on a Linux machine.

Opens a shell, download the vpn file, set the vpn through openvpn, erase traces.

## Getting Started

### Dependencies

* Permissions
* Internet Connection
* 'openvpn' installed

### Executing program

* Plug in your device

### Settings

* Set the VPN file link