# Change Windows User Name

This script can be used to change the windows user name.

**Category**: Execute

## Description

This script can be used to change the windows user name.

The script opens the research app and go to User Accounts settings using the default path `Control Panel\All Control Panel Items\User Accounts`, then go to "Change your account name" option and set the new name, save it and close the app.

It is absurd that you can do so many things on windows without asking for permissions.

### Dependencies

* Set the new name that you want to set

```DuckyScript
DEFINE NEW_NAME example
```