# Stop A Single Process In Windows

This script can be used to quickly stop an active process on a windows machine.

**Category**: Execution

## Description

This script can be used to quickly stop an active process on a windows machine.

This script open the Task Manager app, then go to search bar, then write the process name that want to be stopped, open the right click mouse menu and click the end task option, then close the task manager app.

## Dependencies

* Nothing

## Settings

- Write the name of the process that you want to stop 
    
    `DEFINE PROCESS_NAME example`
