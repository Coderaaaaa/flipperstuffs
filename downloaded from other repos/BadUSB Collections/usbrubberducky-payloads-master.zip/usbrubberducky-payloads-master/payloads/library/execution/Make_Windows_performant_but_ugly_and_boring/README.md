# Make Windows performant (but ugly and boring)

This script can be used to change some advanced Windows settings to make it as efficient as possible albeit losing some of the fluidity and beauty of the operating system.

This script is Plug-And-Play <3

**Category**: Execute

![](Make_Windows_performant_but_ugly_and_boring.gif)

## Description

This script can be used to change some advanced Windows settings to make it as efficient as possible albeit losing some of the fluidity and beauty of the operating system.

The script opens the Windows advanced settings via sysdm.cpl and accesses the advanced settings by changing the selected option for best performance and unchecking all possible features.

### Dependencies

* Nothing is needed, this script is Plug-And-Play <3