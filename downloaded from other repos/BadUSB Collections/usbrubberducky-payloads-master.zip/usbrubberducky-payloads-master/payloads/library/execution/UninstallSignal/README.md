# Uninstall Signal

A script used to uninstall signal-desktop app on Windows users.

**Category**: Execution

## Description

A script used to uninstall signal-desktop app on Windows users.

Open a PowerShell, stop the Signal proccess if it runs and then execute the uninstall file trhough general path.

## Dependencies

* Signal App installed (obviously LOL)
* ExecutionPolicy Bypass

## Settings

- Nothing to set, this payload is Plug-And-Play <3
