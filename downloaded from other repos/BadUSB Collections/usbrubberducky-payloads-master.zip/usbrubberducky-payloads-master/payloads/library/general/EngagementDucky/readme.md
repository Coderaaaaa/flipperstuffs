**Title: EngagementDucky**

<p>Author: 0iphor13<br>
OS: Windows<br>
Requirements: DuckyScript 3.0<br>
Version: 1.0</p>

**What is EngagementDucky?**
#
<p>EngagementDucky will help you generating your evidence. Typical proof of compromise is normally something harmless like a message in notepad on your targets machine. This payload will pop a message box, containing Username, Hostname, Time and Date. Afterwards Ducky will generate a screenshot of this message box and will save it. Afterwards you can walk away. Combine this with specific USB identifiers to help identifying you.<br>
Step up your game and demonstrate impact in a few seconds without leaving your scope.</p>

![alt text](https://github.com/0iphor13/usbrubberducky-payloads/blob/master/payloads/library/general/EngagementDucky/usbidentifiers.png)

**Instruction:**
1. Configure USB identifiers

2. Place inject.bin onto your Ducky

3. Plug in your Ducky and wait until finish... walk away
![alt text](https://github.com/0iphor13/usbrubberducky-payloads/blob/master/payloads/library/general/EngagementDucky/proofpic.png)
