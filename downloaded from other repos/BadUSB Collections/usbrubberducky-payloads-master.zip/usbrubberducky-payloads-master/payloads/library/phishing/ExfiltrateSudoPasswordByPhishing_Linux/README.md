 
# Exfiltrate Sudo Password By Phishing - Linux ✅

A script used to exfiltrate the sudo password by a popup phishing based on linux systems.

**Category**: Credentials, Phishing

## Description

A script used to exfiltrate the sudo password by a popup phishing based on linux systems.

Opens a shell, get the password by a popup, send the input to a Discord webhook.

## Getting Started

### Dependencies

* Internet Connection

### Executing program

* Plug in your device

### Settings

* Set the Discord webhook