 
# Exfiltrate Email And Password By Phising - Linux ✅

A script used to exfiltrate the email and the email password by a popup (KDE/kdialog based) phishing based on linux systems.

**Category**: Phishing, Credentials

## Description

A script used to exfiltrate the email and the email password by a popup (KDE/kdialog based) phishing based on linux systems.

Opens a shell, get the email and the email password by a popup, send the input to a Discord webhook.

## Getting Started

### Dependencies

* Internet Connection
* Discord webhook
* KDE/kdialog based

### Executing program

* Plug in your device

### Settings

* Set the Discord webhook