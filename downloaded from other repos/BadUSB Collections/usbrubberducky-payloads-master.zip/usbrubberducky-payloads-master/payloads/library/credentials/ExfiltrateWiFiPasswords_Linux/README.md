 
# Exfiltrate WiFi Passwords - Linux ✅

A script used to exfiltrate the wifi passwords on a Linux machine.

**Category**: Exfiltrate, Credentials, Execution

## Description

A script used to exfiltrate the wifi passwords on a Linux machine.

Opens a shell, get the WiFi names, get the passwords using nmcli, send the result to Dropbox, erase traces.

## Getting Started

### Dependencies

* Internet Connection
* Dropbox Token
* Permissions

### Executing program

* Plug in your device

### Settings

* Set the Dropbox token
* Set the sudo password