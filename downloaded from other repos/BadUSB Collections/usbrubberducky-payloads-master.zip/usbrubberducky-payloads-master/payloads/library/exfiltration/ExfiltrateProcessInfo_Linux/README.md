 
# Exfiltrate Process Info - Linux ✅

A script used to exfiltrate the process info on a Linux machine.

**Category**: Exfiltration

## Description

A script used to exfiltrate the process info on a Linux machine.

Opens a shell, get the process info, set the Discord webhook configuration, send it to the discord webhook, erase traces.

## Getting Started

### Dependencies

* Internet Connection
* Discord Webhook

### Executing program

* Plug in your device

### Settings

* Set the Discord Webhook configuration