# Exfiltrate Network Traffic - Linux ✅

A script used to exfiltrate the network traffic on a Linux machine.

**Category**: Exfiltrate

## Description

A script used to exfiltrate the network traffic on a Linux machine.

Opens a shell, get the network card name, get the network traffic using tcpdump, send the result to Dropbox, erase traces.

## Getting Started

### Dependencies

* Permissions
* Internet Connection

### Executing program

* Plug in your device

### Settings

* Set the Dropbox token
* Set the sniffing filter