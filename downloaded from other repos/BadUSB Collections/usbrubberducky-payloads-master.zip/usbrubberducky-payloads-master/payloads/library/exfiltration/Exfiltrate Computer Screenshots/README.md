# Exfiltrate Computer Screenshots

A script used to prank your friends exfiltrating some screenshots.

**Category**: Exfiltration

## Description

A script used to prank your friends exfiltrating some screenshots.

Open a PowerShell, download the Python script and execute it. The Python script will make some screenshot that will be sent, through the discord webhook, to you.

## Getting Started

### Dependencies

* Internet Connection
* Discord Webhook (or whatever you want for the exfiltration)
* ExecutionPolicy Bypass
* Python

### Executing program

* Plug in your device

### Settings

- Setup your Python script link in the payload.txt file
- Setup your Discord webhook link in the script.py file
