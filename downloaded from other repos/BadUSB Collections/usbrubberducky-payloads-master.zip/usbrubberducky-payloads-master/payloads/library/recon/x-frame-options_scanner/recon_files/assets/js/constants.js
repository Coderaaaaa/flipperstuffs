const LAN = (new URLSearchParams(document.location.search).get('lan'));
const OUTPUT = document.querySelector('#output');