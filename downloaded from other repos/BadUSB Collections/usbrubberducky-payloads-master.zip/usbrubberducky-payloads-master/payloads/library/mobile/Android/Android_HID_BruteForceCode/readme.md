# Brute Force
- Author: Cribbit
- Version: 1.0
- Target: Android < 6 (I think)
- Category: Mobile
- Attackmode: HID
- Props: *[Hak5Darren](https://github.com/hak5darren)* for original idea, *[Kalani](https://github.com/kalanihelekunihi)* & Shinichi Kudo for info on backspace CVE

## Description
An updated version of Hak5 episode 1217.1 android pin brute force method using just Ducky Script 3. Please note this brute force method is at least 10-year-old at time of writing. So, will not work on modern android phones. But gives you a PoC of a way it could of be written.

There is also a version to work with CVE-2017-10709 that uses backspaces.

Click the image below to watch the original Hak5 Video:  
[![Hak5 1217.1, Hack any 4-digit Android PIN in 16 hours with a USB Rubber Ducky](https://img.youtube.com/vi/yoYiEkk5TyI/0.jpg)](https://www.youtube.com/watch?v=yoYiEkk5TyI)

## Change Log
| Version | Changes         |
| ------- | --------------- |
| 1.0     | Initial release |

