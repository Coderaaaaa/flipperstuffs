# :grapes: Hey! Got Any Grapes?
- Author: Cribbit
- Version: 1.0
- Target: Windows, Mac & linux 
- Category: Prank
- Attackmode: HID
- Props: Song by Bryant Oden


## :book: Description
Get Windows "powershell" or MacOS "say" or Linux (ubuntu) "espeak" to speak the opening of the duck song

## :warning: Note
espeak need to be install on a linux system for it to work

## :placard: Change Log
| Version | Changes         |
| ------- | --------------- |
| 1.0     | Initial release |

