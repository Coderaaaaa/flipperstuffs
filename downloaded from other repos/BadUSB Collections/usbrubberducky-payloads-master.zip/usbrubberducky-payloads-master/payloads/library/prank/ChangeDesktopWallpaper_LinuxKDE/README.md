# Change Desktop Wallpaper - Linux ✅

A script used to prank your friends changing their desktop wallpaper.

**Category**: Prank

## Description

A script used to prank your friends changing their desktop wallpaper.

Opens a shell, download the image, define the local image path, run a command KDE BASED that will replace the desktop wallpaper with the local image path, then delete the image downloaded, clear the history and close the shell.

## Getting Started

### Dependencies

* Internet Connection
* Linux KDE

### Executing program

* Plug in your device

### Settings

- Image link
- Local image path
