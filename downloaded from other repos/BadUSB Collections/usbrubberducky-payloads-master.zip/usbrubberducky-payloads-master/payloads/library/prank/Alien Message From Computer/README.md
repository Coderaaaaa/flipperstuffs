# Alien Message From Computer

A script used to prank your friends with a script that simulate an Alien inside the computer.

**Category**: Prank

## Description

A script used to prank your friends with a script that simulate an Alien inside the computer.

Open a PowerShell, download the Python script and execute it. The Python script will simulate the Alien using the Python library pyttsx3.

## Getting Started

### Dependencies

* Internet Connection
* ExecutionPolicy Bypass
* Python

### Executing program

* Plug in your device

### Settings

* Nothing to setup, it is Plug-And-Play

### FAQs

- Why is the code in one line?
  - In Python if TAB errors are made then execution is blocked so to avoid writing so many DuckyScript STRING elements I wrote everything in one line separating each command by a semicolon. However, the code can be viewed entirely in the script.py file and edited as desired.