# Horsd - In memorium to my Nan
Changes the target users background to a picture of a brown horse running, a nod to my nan's laptop background.
** This script requires very minor configuration found on LN:23 of the payload, set your own direct access link to the horsd.ps1 powershell script.