# Continuos Print In Terminal

Plug And Play

A script used to prank your friends with a terminal print.

**Category**: Prank

## Description

A script used to prank your friends with a terminal print.

Open a PowerShell, download the Python script and execute it. The Python script will print in output (everytime with a different color) the phrase "Your computer is infected!".

## Getting Started

### Dependencies

* Internet Connection
* ExecutionPolicy Bypass
* Python

### Executing program

* Plug in your device
