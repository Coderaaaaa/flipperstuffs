This is a simple Ducky Script that recreates the "Wake up Neo" or "Follow the white rabbit" [terminal scene from The Matrix](https://youtu.be/6IDT3MpSCKI?t=28).

![Short_Example](https://user-images.githubusercontent.com/57457139/165814938-259abe8e-9d9a-4ca9-b40b-f2214b7c3fb4.gif)

Basic Ducky Script, should work on all supported devices. Beeps at the end require Powershell 2.0 or above, everything else is just text in the CMD prompt.

Launches CMD, changes to green text, makes full screen, types out the scene, then obscures the prompt and beeps (knocks) twice, then exits.

Kudos to [Kalani](https://github.com/kalanihelekunihi), [MG](https://github.com/OMG-MG), [I-Am-Jakoby](https://github.com/I-Am-Jakoby), and [Hak5](https://hak5.org/) for help and support!
