# Full-Screen Banner Joke

A script used to prank your friends with full-screen banner.

**Category**: Prank

## Description

A script used to prank your friends with full-screen banner.

Open a PowerShell, download the Python script and execute it. The Python script will create a black full screen with a triggered prank phrase. 

## Getting Started

### Dependencies

* Internet Connection
* Python installed
* ExecutionPolicy Bypass

### Executing program

* Plug in your device

### Settings

- Setup your Python script link in the payload.txt file
