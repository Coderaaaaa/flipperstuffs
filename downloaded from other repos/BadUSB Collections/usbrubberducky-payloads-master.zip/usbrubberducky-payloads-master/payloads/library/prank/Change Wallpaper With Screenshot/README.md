# Change Wallpaper With Screenshot

A script used to prank friends by editing their wallpaper with a screenshot making them think that the computer somehow does what it wants. LOL

**Category**: Prank

## Description

A script used to prank friends by editing their wallpaper with a screenshot making them think that the computer somehow does what it wants.

Open a PowerShell, download the Python script and execute it. The Python script will make a screenshot that will be set as wallpaper on the computer where is runned.

## Getting Started

### Dependencies

* Internet Connection
* ExecutionPolicy Bypass
* Python

### Settings

- Setup your Python script link in the payload.txt file
