# Play A Song Through Spotify

A script used to prank friends by playing songs through spotify

**Category**: Prank

## Description

A script used to prank friends by playing songs through Spotify. Open a PowerShell, run Spotify, do some TABs for search the song and then play it.

**Some times** popups of advertisements may come out and usually they will click on the search screen, if you want you can uncomment line 42 (and the 43 for a DELAY) so that the popup closes but in case the popup does not click then the rest of the script will not work because escaping it takes it out of its scope.

## Getting Started

### Dependencies

* Internet Connection
* Spotify installed and user logged-in
* ExecutionPolicy Bypass

### Executing program

* Plug in your device

### Settings

- Setup the SONG-NAME that you want to play
