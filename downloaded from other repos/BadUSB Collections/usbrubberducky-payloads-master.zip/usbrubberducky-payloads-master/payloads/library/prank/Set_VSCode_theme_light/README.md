# Set VSCode to light theme - MacOS ✅

 Plug-And-Play ❤️

A script that sets the VSCode theme to light to let the nightmare of every developer come true!

 **Category**: Execution

 ## Description

A script that opens VSCode, goes to the settings, changes the theme and then sneakily closes the settings again.

 ## Getting Started

 ### Dependencies

 * MacOS system
 * VSCode installed

 ### Executing program

 * Plug in your device

 ### Settings
 *None*
 

https://user-images.githubusercontent.com/69253692/231779555-bb0e86d1-61ae-4170-809e-0f0723c58445.mov
