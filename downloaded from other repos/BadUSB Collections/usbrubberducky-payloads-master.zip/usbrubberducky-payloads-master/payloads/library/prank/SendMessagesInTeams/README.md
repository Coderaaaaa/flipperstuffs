# Send Messages In Teams

A script used to prank your friends sending a message through the user Teams.

**Category**: Prank

## Description

A script used to prank your friends sending a message through the user Teams.

Open a PowerShell, stop Teams if is runned, run Teams, run new message function, search the receiver, write and send some messages, then close the app.

## Getting Started

### Dependencies

* Internet Connection
* Microsoft Teams installed and user logged-in
* ExecutionPolicy Bypass
* Python

### Settings

- Setup the receiver
