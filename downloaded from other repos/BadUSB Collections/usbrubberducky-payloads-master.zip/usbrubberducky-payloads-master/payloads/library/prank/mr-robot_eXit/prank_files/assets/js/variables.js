var level;
level = 0;

var iterator;
iterator = 0;

var response;
response = stage(level, iterator);