# The Mouse Moves By Itself

A script used to prank your friends with the mouse pointer.

**Category**: Prank

## Description

A script used to prank your friends with the mouse pointer.

Opens a shell, dowloand the Python script that will prank your friends mouving the mouse pointer.

## Getting Started

### Dependencies

* Internet Connection

### Settings

- Setup your Python script link in the payload.txt file
