# Security Policy

- Our project includes scripts that can potentially harm devices. As such, we strongly advise against using these scripts without obtaining explicit permission to run these scripts.

- By using these scripts, you assume all responsibility for any damage that may occur to your devices. The project maintainers will not be held liable for any harm caused by the use of these scripts.

- Additionally, we advise against using these scripts on any devices that are important to you or that you do not have explicit permission to modify. The scripts may potentially damage or render devices inoperable.

- Please use these scripts at your own risk and with caution. We do not condone any illegal or malicious activities.
