# Original repo
https://github.com/FalsePhilosopher/badusb/tree/main/destructive/Win/Delete32

# 32 Wants the D

This script deletes the system 32 folder. Be careful!




## How to use?

This script is plug and play. I am not responsible for any damage.




## Features

- open powershell
- delete system 32





## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


