
# setWinPass

This script sets the password for the current user on windows.


## How to use?

This script is not plug and play. You will have to do the following changes:

- change password to anything you like "$NewPassword = ConvertTo-SecureString "PASSWORD HERE""


## Features

- open powershell 
- find current username
- set new password for current user





## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


