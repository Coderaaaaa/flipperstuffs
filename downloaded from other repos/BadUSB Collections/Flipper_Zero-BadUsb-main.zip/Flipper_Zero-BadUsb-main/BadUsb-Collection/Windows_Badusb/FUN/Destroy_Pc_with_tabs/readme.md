
# Destroy_Pc_with_tabs
Opens a few tabs... maybe too many.

## How to use?

This script is plug and play.


## Features

- open powershell 
- use system.speech to talk


## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


