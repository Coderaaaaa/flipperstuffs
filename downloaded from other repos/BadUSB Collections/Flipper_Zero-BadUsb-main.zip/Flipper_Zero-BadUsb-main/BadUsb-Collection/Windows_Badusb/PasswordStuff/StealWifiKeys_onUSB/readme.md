
# StealWifiKeys_onUSB
Steals all of the saved Wifi Passwords and stores them into a file, then puts the file on a usb device connected to the target pc.

## How to use?

This script is not plug and play and only for experienced users. You will need to do the following changes:

- change path to the usb device "-DestinationPath File path on USB device here"


## Features

- open powershell
- grab wifi keys
- store keys to a file on a usb device

## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


