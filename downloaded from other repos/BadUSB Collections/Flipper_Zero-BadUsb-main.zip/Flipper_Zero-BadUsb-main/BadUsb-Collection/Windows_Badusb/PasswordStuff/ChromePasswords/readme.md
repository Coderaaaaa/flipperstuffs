
# chrome_passwords_discord
Grabs the "key" and "login data" file for google chrome and sends them to a discord webhook. To decrypt please read below.

## How to use?

Well this script is kind of plug and play. After the two files ("encryped passwords" and "key.txt") got sent to your webhook, you will have to decrypt the passwords.

To do this, I have coded a python program that will use the grabbed "key" to decrypt the passwords.

Get the [program]


## Features

- open powershell
- grab 2 files
- send files to webhook

## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".

[program]: https://github.com/UNC0V3R3D/ChromeDecrypter




## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


