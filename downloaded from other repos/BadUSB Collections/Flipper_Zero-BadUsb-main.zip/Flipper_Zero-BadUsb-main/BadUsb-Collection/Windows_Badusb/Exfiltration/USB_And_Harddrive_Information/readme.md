
# USB_And_Harddrive_Information
Saves some general Information about the USB and Harddrives that are/were connected to the target pc and stores them into a file.

## How to use?

This script is not plug and play. You need to do the following changes:

- change the path of the file "-DestinationPath PATH TO SAVE FILE HERE\HEREresults-68597243.zip"


## Features

- open powershell 
- get hardware info
- save infos to a file


## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


