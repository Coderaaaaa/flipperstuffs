
# IP_To_Discord
Saves the IP of the target pc to a discord webhook.

## How to use?

This script is not plug and play. You need to do the following changes:

- change the url of the discord webhook "$url="DISCORD WEBHOOK LINK""


## Features

- open powershell 
- get ip adress
- send file with ip to webhook



## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


