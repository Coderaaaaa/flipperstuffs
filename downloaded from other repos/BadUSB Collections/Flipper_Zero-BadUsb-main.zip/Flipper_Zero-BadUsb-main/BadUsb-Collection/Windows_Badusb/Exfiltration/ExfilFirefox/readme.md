
# ExfilFirefox
This script exfiltrates the firefox profile and saves them to a local html file.

## How to use?

This script is not plug and play. You need to do the following changes:

- change path of the file "-DestinationPath PATH\results-26528702.zip"


## Features

- open powershell 
- copy firefox profile
- paste profile into a html file



## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


