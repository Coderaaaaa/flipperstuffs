
# iPhone_open_website

This script will open any website on an iPhone.




## How to use?

This script is not plug and play. Insert the url that you want to open right here "STRING www.yourwebsite.com"




## Features

- open website




## Feedback

If you have any feedback, please reach out to me via Discord "UNC0V3R3D#8662".






## Support

For support, contact me via  Discord "UNC0V3R3D#8662".


## Meta


- If you want to sponsor me on Patreon, the link is on my profile.


